export class Registration {
     public id!: string
    public firstName!: string
    public lastName!: string
    public mobile_No!: number
    public email!: string
    public password!: string
    public city!: string
    public age!: string
}
