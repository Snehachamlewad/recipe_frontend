import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core'
import { Registration } from './registration';

@Injectable({
  providedIn: 'root'
})
export class RestService {

  constructor(@Inject(HttpClient) private client : any) { }

  registrationUrl = "https://localhost:7137/api/Registration/";

  getData!: Registration;

  getRegisteredUser() {
    return this.client.get(this.registrationUrl);
  }
  postUser(userGroup:any) {
    return this.client.post(this.registrationUrl,userGroup);
  }

}
